#Subiect 3 (2.5 pts)
#TOPIC: REACT

# Dată fiind aplicația modificati codul sursă astfel încât:

- Aplicația se desenează fără eroare; (0.5 pts)
- Se desenează o componentă RobotForm; (0.5 pts)
- RobotForm are o proprietate `onAdd` care conține o funcție; (0.5 pts)
- Dat fiind că input-urile pentru proprietățile robotului au id-urile `name`, `type` and `mass` și că butonul de adăugare are valoarea `add` se poate adăuga un robot;(0.5 pts)
- Robotul adăugat are valorile corecte în proprietăți. (0.5 pts)